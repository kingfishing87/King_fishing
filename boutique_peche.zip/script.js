const products = [
    { id: 1, name: "Canne à pêche carbone", price: 45 },
    { id: 2, name: "Moulinet Shimano", price: 65 },
    { id: 3, name: "Set de leurres", price: 20 },
    { id: 4, name: "Boîte de rangement", price: 15 }
];

let cart = [];

function renderProducts() {
    const grid = document.getElementById('productGrid');
    products.forEach(product => {
        const div = document.createElement('div');
        div.className = 'product';
        div.innerHTML = `
            <h3>${product.name}</h3>
            <p>${product.price}€</p>
            <button onclick="addToCart(${product.id})">Ajouter au panier</button>
        `;
        grid.appendChild(div);
    });
}

function addToCart(id) {
    const item = products.find(p => p.id === id);
    cart.push(item);
    alert(`${item.name} ajouté au panier.`);
}

function viewCart() {
    const modal = document.getElementById("cartModal");
    const list = document.getElementById("cartItems");
    const total = document.getElementById("cartTotal");
    list.innerHTML = "";
    let sum = 0;
    cart.forEach(item => {
        const li = document.createElement("li");
        li.textContent = `${item.name} - ${item.price}€`;
        list.appendChild(li);
        sum += item.price;
    });
    total.textContent = sum + "€";
    modal.style.display = "flex";
}

function closeCart() {
    document.getElementById("cartModal").style.display = "none";
}

window.onload = renderProducts;